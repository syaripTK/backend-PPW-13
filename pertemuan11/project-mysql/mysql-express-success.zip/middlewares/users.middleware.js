import { koneksi } from "../config/db.js";
import respond from "../payload/response.js";

const cekId = async (req, res, next) => {
  const { id } = req.params;
  const [data] = await koneksi.query("SELECT * FROM user WHERE id_user=?", [
    id,
  ]);
  if (data.length === 0) {
    return respond(res, 404, "Data tidak ditemukan");
  }

  next();
};

const cekInput = (req, res, next) => {
  if (!req.body) {
    return respond(res, 404, "Req body harus diisi");
  }
  const { username, email, status } = req.body;
  if (!username || !email || !status) {
    return res
      .status(404)
      .json({ message: "Username, Email, dan Status harus diisi" });
  }
  next();
};

const checkBeforeDelete = async (req, res, next) => {
  const { id } = req.params;
  const [data] = await koneksi.query("SELECT * FROM user WHERE id_user=?", [
    id,
  ]);
  if (data.length === 0) {
    return respond(res, 404, "Data tidak ditemukan");
  }
  next();
};

const checkBeforeUpdate = async (req, res, next) => {
  if (!req.body) {
    return respond(res, 400, "Req body harus diisi");
  }
  const { id } = req.params;
  const { username, email, status } = req.body;
  const [data] = await koneksi.query("SELECT * FROM user WHERE id_user=?", [
    id,
  ]);
  if (data.length === 0) {
    return respond(res, 404, "Data tidak ditemukan");
  }
  if (!username || !email || !status) {
    return respond(res, 400, "Username, email, status harus diisi");
  }
  next();
};

export { cekId, cekInput, checkBeforeDelete, checkBeforeUpdate };
